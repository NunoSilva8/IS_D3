package database;

public interface DataBaseUtils {
      String DATABASE_URL = "jdbc:mysql://localhost:3306/project3";
      String USERNAME = "projeto";
      String PASSWORD = "projeto";
}
